<?php
$config = [
"u=61368807;n=ffffffffd648b9aa0000000025644a2b", //akun 1
"u=62290839;n=ffffffffbf064d880000000025644a2b", //akun 2 dst

];
