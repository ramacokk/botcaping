# capingfull
bot caping full versi
